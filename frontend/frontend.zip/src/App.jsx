import React from 'react';
import Dashboard from './dashboard';
import './App.css';

function App() {
  return <Dashboard />;
}

export default App;